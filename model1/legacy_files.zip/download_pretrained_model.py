#!/usr/bin/env python
"""
Downloads the pretrained Zhang et al. (2016) "Colorful Image Colorization"
Caffe model files needed for inference. Run this once before using
colorize_pretrained.py or app_pretrained.py.

Files downloaded into ./models/:
    colorization_deploy_v2.prototxt   (network architecture definition)
    pts_in_hull.npy                    (313 quantized color cluster centers)
    colorization_release_v2.caffemodel (trained weights, ~130MB)
"""
import os
import urllib.request

MODEL_DIR = "models"

FILES = {
    "colorization_deploy_v2.prototxt":
        "https://raw.githubusercontent.com/richzhang/colorization/caffe/colorization/models/colorization_deploy_v2.prototxt",
    "pts_in_hull.npy":
        "https://raw.githubusercontent.com/richzhang/colorization/caffe/colorization/resources/pts_in_hull.npy",
    "colorization_release_v2.caffemodel":
        "http://eecs.berkeley.edu/~rich.zhang/projects/2016_colorization/files/demo_v2/colorization_release_v2.caffemodel",
}

# Fallback mirror if the Berkeley URL above is ever down:
# https://www.dropbox.com/scl/fi/d8zffur3wmd4wet58dp9x/colorization_release_v2.caffemodel?rlkey=iippu6vtsrox3pxkeohcuh4oy&dl=1


def download(url: str, dest: str):
    if os.path.exists(dest):
        print(f"Already exists, skipping: {dest}")
        return
    print(f"Downloading {dest} ...")
    urllib.request.urlretrieve(url, dest)
    size_mb = os.path.getsize(dest) / (1024 * 1024)
    print(f"  Done ({size_mb:.1f} MB)")


if __name__ == "__main__":
    os.makedirs(MODEL_DIR, exist_ok=True)
    for filename, url in FILES.items():
        dest = os.path.join(MODEL_DIR, filename)
        try:
            download(url, dest)
        except Exception as e:
            print(f"  FAILED: {e}")
            print(f"  Try downloading manually from: {url}")
    print("\nDone. Model files should now be in ./models/")
